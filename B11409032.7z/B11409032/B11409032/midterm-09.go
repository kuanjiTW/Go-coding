// Score: 5
/*
  (5 分)

  將<code>置換成合適的布林（Boolean）運算子（operators）使得
  程式會輸出`Safe!`。
*/

package main

import "fmt"

func main() {
  x := 10
  y := 13
  z := 17
  b1 := x < y//true
  b2 := x > z//false
  b3 := x + y > 2 * z//false
  if b1 && b2 && !b3 {
    fmt.Println("Boom!")
  } else {
    fmt.Println("Safe!")
  }
}
