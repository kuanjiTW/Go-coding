// Score: 5
/*
  (5 分)

  將<code>置換成某個表達式（expression），使得程式會輸出
  `がんばってください`。表達式是指將運算子（operators）
  和函式應用於運算元（operands）上而計算出某個值。
*/

package main

import "fmt"

func main() {
  str := "がんばってください"
  for _, c := range str {
    fmt.Print(string(c))
    
  }
  fmt.Println()

}
