// Score: 10
/*
  (10 分)

  寫一個完整的 Go 程式，用來實作雙指針合併演算法（two-pointer
  merge algorithm）。該程式應將兩個預先排序好、固定大小的整數
  陣列（xs 和 ys）合併成一個單一的、已排序的陣列（zs）。

  1. 初始化兩個已排序的輸入陣列和一個空的結果陣列，使用指定的
     數值和大小：
       xs := [5]int{1, 2, 8, 10, 17}
       ys := [5]int{3, 5, 10, 15, 21}
       zs := [10]int{}
  2. 編寫一個單一的 for 迴圈，在遍歷兩個輸入陣列時，維護三個
     索引：
       - i：xs 中待訪問整數的索引。
       - j：ys 中待訪問整數的索引。
       - k：zs 中下一個可用位置的索引。
     在每一次迭代（iteration）中，比較 xs（即 xs[i]）和 ys
    （即 ys[j]）中最小的未合併元素，並將較小者放入 zs 中下一
     個可用位置（即 zs[k]）。索引 i、j 和 k 視情況推進。
  3. 迴圈必須包含邏輯來處理邊界條件，即其中一個輸入陣列（xs
     或 ys）在另一個陣列之前已被完全消耗完畢的情況。
  4. 在程式結束時，印出結果陣列 zs。

  預期輸出為：`[1 2 3 5 8 10 10 15 17 21]`。
*/
package main 

import "fmt"

func main(){
  xs := [5]int{1, 2, 8, 10, 17}
  ys := [5]int{3, 5, 10, 15, 21}
  zs := [10]int{}
  var (
    i int =0
    j int =0
  )
  for k := 0 ;k < len(zs);k++{


    if xs[i]<ys[j]{
      zs[k]=xs[i]
      i++
    }else if xs[i] > ys[j]{
      zs[k]=ys[j]
      j++
    }else if xs[i] == ys[j]{
      zs[k]=xs[i]
      i++
    }

    

    if i >= len(xs){
      i=len(xs)-1
    }
    if j >= len(ys){
      j =len(ys)-1
    }

    if k==len(zs)-1{
      if xs[i]> ys[j]{
        zs[k]=xs[i]
      }else if xs[i] < ys[j]{
        zs[k]=ys[j]
      }
    }
    
  }

  fmt.Println(zs)
}
