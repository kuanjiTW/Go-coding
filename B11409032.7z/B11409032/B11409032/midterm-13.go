// Score: 9
// Note: the height of the printed rectangle is `height + 1`
/*
  (10 分)

  寫一個完整的Go程式，使用星號（*）印出空心的矩形。

  程式應該：
  1. 定義兩個整數變數：width（例如7）和height（例如5）。
  2. 使用巢狀for迴圈（nested for loops）和if陳述式判斷要
     印出星號或空格。
  3. 最上端和最下端的兩列應該都是星號。
  4. 中間的各列只有第一個跟最後一個字元是星號，其他都是空格。
  5. 確保在每一列的最後有適當的換行。

  禁止使用`strings.Repeat`。

  範例輸出（width=7且height=5時）：
  *******
  *     *
  *     *
  *     *
  *******
*/
package main

import "fmt"

func main(){
  var(
    width int
    height int
  )

  fmt.Scan(&width,&height)
  for i:=0;i<=height;i++{
    for j:= 0;j<width;j++{
      if i==0 || i == height || j == 0 || j == width-1{
        fmt.Print("*")
      }else{
        fmt.Print(" ")
      }
    }
    fmt.Println()
  }
}
