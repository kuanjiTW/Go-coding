// Score: 7
// Note: not working for unicode characters
/*
  (10 分)

  寫一個完整的Go程式，從fmt.Scan讀取一個輸入字串，然後印出
  該輸入字串的顛倒（頭尾顛倒）。可以假設輸入的字串不會包含
  空格。例如輸入字串為"HelloWorld"，則程式會輸出`dlroWolleH`。
*/

package main

import "fmt"

func main() {
	var str string
	fmt.Scan(&str)
	xs := []rune(str)
	for i := 0; i < len(xs); i++ {
		fmt.Print(string(str[len(xs)-i-1]))
	}
	fmt.Println()
}
