// Score: 5
/*
  (5 分)

  將<code>置換成一個整數，使得程式會輸出53。
  程式中的`len(xs)`代表陣列xs的大小（長度、陣列中元素個數）。
*/

package main

import "fmt"

func main() {
  var xs = [...]int{50: 3, 4, 5, 2: 6}
  fmt.Println(len(xs))
}
