// Score: 0
/*
  (5 分)

  哪一個在Go和其他程式語言的標準技巧可以用來正確判斷兩個浮點數
  `a`和`b`是否被視為相等。

  a. 四捨五入至小數點以下兩位後比較兩個數字。
  b. 使用標準函式庫的`CompareFloats(a, b)`函式。
  c. 檢查兩者之差的絕對值是否小於某個小的容忍值（epsilon）。
  d. 使用特殊的`floatEqual`運算。

  以你的答案初始化變數`ans`。
*/

package main

import "fmt"

var ans string = "b"

func main() {
  fmt.Println(ans)
}
