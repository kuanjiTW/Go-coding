// Score: 5
/*
  (5 分)

  將<code>置換成適合的後置陳述式（post-statement），使得
  程式會輸出`[7 5 3 9 4 1]`。
*/

package main

import "fmt"

func main() {
  xs := []int{1, 4, 9, 3, 5, 7}
  size := len(xs) // len(xs) = 6
  for i := 0; i < size;i+=2 {
    xs[i], xs[size - i - 1] = xs[size - i - 1], xs[i]
  }
  fmt.Println(xs)
}
