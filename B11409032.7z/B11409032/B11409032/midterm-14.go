// Score: 10
/*
  (10 分)

  寫一個完整的Go程式，計算並印出以下整數陣列的統計資訊。

    [...]int{37, 56, 89, 82, 93, 78, 84}

  統計資訊包含總和（sum）、平均數（mean、average）和標準
  差（standard deviation）。平均數與標準差的精確度到小數
  點以下第二位。

  給定m個數字n_1、n_2、...、n_m，下面的數學等式描述如何
  計算總和、平均數和標準差（stdev）。
  - sum = Σ n_i
        = n_1 + n_2 + ... + n_m
  - mean = sum / m
  - variance = (Σ (n_i - mean)^2) / m
             = ((n_1 - mean)^2 + (n_2 - mean)^2 + ... + (n_m - mean)^2) / m
  - stdev = variance的平方根

  備註:
  - n的m次方寫作n^m。
  - 可以使用float64(n)將整數n轉變成float64。
  - 可以使用math.Pow(n, m)計算n^m。
  - 可以使用math.Sqrt(n)計算float64浮點數n的平方根。
*/
package main

import ("fmt" ;"math")

func main(){
  arr := [...]int{37, 56, 89, 82, 93, 78, 84}
  sum := 0
  
  var (
    avg float64
    variance float64
    SumForVar float64
    stdev float64
  )
  for _,v:=range arr{
    sum += v
  }

  avg = float64(sum)/float64(len(arr))

  for i:=0;i<len(arr);i++{
    SumForVar += (math.Pow((float64(arr[i])-avg),2))
  }
  variance = SumForVar / float64(len(arr))
  stdev = math.Sqrt(variance)
  fmt.Println(sum)
  fmt.Printf("%.02f\n",avg)
  fmt.Printf("%.02f\n",stdev)
}
