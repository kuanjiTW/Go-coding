// Score: 9
// Note: not working for n = 2
/*
  (10 分)

  寫一個完整的Go程式並滿足以下要求。

  1. 定義一個大小為10的整數陣列xs。
       xs := [10]int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
  2. 從標準輸入讀取一個整數，將該整數存於變數n。
  3. 印出陣列xs中最後一個小於n的整數所在索引位置（index），
     若陣列中無該整數，則印出`-1`。

  例如n是8的時候，程式會印出6，因為陣列xs中最後一個小於8的
  數字是7，而7在xs中的索引值為6。
*/
package main

import "fmt"

func main(){
  xs := [10]int{1,2,3,4,5,6,7,8,9,10}
  var n int
  found:=false
  fmt.Scan(&n)
  
  for i :=len(xs)-1;i>0;i--{
    if(n>xs[i]){
      fmt.Println(i)
      found =true
      break
    }
  }
  if found ==false{
    fmt.Println("-1")
  }
}
