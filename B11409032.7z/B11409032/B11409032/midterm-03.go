// Score: 5
/*
  (5 分)

  在多重賦值（multiple assignment）之後，變數`b`的值為何？

  ```
  var a, b int = 10, 20
  b, a, b = 2 * a, 3 * b, 4 * a
  ```

  a. 20
  b. 30
  c. 40
  d. 240

  以你的答案初始化變數`ans`。
*/

package main

import "fmt"

var ans string = "c"

func main() {
  fmt.Println(ans)
}
