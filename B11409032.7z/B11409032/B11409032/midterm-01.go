// Score: 5
/*
  (5 分)

  程式最後的`fmt.Println(x)`所印出變數x最終值爲何？

  ```
  func main() {
    x := 10
    if true {
      x := 20
      // fmt.Println(x) // 印出 20
    }
    // 這裡x的值是什麼？
    fmt.Println(x)
  }
  ```

  a. 20
  b. 編譯時錯誤
  c. nil
  d. 10

  以你的答案初始化變數`ans`。
*/

package main

import "fmt"

var ans string = "d"

func main() {
  fmt.Println(ans)
}
