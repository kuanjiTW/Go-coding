// Score: 5
/*
  (5 分)

  將<code>置換成某個表達式，使得程式會輸出`Negative`。
*/

package main

import "fmt"

func main() {
  switch x := 10;x!=10{
    case x > 0: fmt.Println("Positive")
    case x < 0: fmt.Println("Negative")
    default: fmt.Println("Zero")
  }
}
