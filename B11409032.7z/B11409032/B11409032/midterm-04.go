// Score: 5
/*
  (5 分)

  Go的無標籤switch敘述（tagless 'switch', 以`switch { ... }`的形式
  出現）在功用上跟連續的哪個其他控制邏輯敘述相當？

  a. if-else if-else if-...
  b. if-if-if-...
  c. if-for-if-for-...
  d. for-if-for-if-...

  以你的答案初始化變數`ans`。
*/

package main

import "fmt"

var ans string = "a"

func main() {
  fmt.Println(ans)
}
