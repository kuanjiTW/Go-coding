// Score: 5
/*
  (5 分)

  底下的常數宣告區塊使用了`iota`關鍵字，請問常數`C`的值為何？

  ```
  const (
    A = iota * 2 + 1
    B
    C
  )
  ```

  a. 3
  b. 7
  c. 編譯時錯誤
  d. 5

  以你的答案初始化變數`ans`。
*/

package main

import "fmt"

var ans string = "d"

func main() {
  fmt.Println(ans)
}
