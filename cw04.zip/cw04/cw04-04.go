/*
  (25 points)

  Follow the instructions below.
  1. Declare a type `named` as a struct with the following fields:
     - name (of type `string`)
  2. Declare a type `person` as a struct composition with `named`
     embedded and with the following additional fields:
     - email (of type `string`)
     - birthYear (of type `int`)
  3. Declare a type `book` as a struct composition with `named`
     embedded and with the following additional fields:
     - author (of type `person`)
     - publishYear (of type `int`)
  4. Declare two different instances of `person`.
  5. Declare two different instances of `book`.
  6. Print the two instances of `book`.
*/

package main

import "fmt"

func main() {
  // --- <code begin> ---

  // --- <code end> ---
}
