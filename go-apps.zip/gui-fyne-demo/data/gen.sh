#!/bin/sh

fyne bundle -o metadata_bundled.go -package data -name resourceAuthors ../../fyne/AUTHORS

