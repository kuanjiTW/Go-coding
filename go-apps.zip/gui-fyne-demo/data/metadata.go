package data

// Authors contains the list of the toolkit authors, extracted from ../../../AUTHORS.
var Authors = resourceAuthors
