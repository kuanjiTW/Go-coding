
Introduction
============

The application demonstrates a simple Web application for
editing plaintext files. The Go source files are adapted from
[Go Wiki](https://go.dev/doc/articles/wiki/).

Usage
=====

1. Run the Web server.
   ```
   $ go run main.go
   ```
2. Run a browser and visit the URL:
   [http://localhost:8080/view/NewPage](http://localhost:8080/view/NewPage).
   You may change the name (NewPage) of the page.
