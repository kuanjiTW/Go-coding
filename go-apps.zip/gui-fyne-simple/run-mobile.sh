#!/bin/bash

go run -tags mobile main.go
