package constants

const (
	RequestIDHeader       = "X-Request-ID"
	DatastarRequestHeader = "Datastar-Request"
)
