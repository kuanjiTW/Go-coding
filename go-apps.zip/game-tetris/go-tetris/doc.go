/*
go-tetris is a simple console-based tetris game written in Go. It takes no options to run. Simply type:

	$ go-tetris

after installing.
*/
package documentation
