
Introduction
============

This folder contains a terminal implementation of Tetris from
[go-tetris](https://github.com/cespare/go-tetris/).
The implementation uses the package
[termbox-go](github.com/nsf/termbox-go) to draw tetrominoes.
