
Introduction
============

This folder contains a terminal-based snake game implementation
adapted from [SnakeInGo](https://github.com/erap129/SnakeInGo).
A tutorial of building this game is available at
[this page](https://medium.com/better-programming/build-a-snake-game-using-in-go-b4186e21d011).
The implementation uses the package
[Tcell](https://github.com/gdamore/tcell) to draw the snake
on the terminal.
